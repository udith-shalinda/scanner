import 'package:flutter/material.dart';
import 'package:scanner/ui/scan.dart';


void main() => runApp(
    new MaterialApp(
      title:'Weather app',
      home: new Scan(),
    )
);